package com.example.demo_project_2024_02_13

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
